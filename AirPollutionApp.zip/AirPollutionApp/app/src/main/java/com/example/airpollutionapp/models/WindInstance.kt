package com.example.airpollutionapp.models

object WindInstance {
    var speed = 0
    var deg = 0
}