package com.example.airpollutionapp.room.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.airpollutionapp.models.Station
import com.example.airpollutionapp.room.dao.StationDao
import com.example.airpollutionapp.room.entity.StationEntity

@Database(entities = [StationEntity::class], version = 2, exportSchema = false)
abstract class LocalDB:RoomDatabase() {

    companion object {
        var database:LocalDB? = null

        @Synchronized
        fun getDatabase(context: Context):LocalDB {
            if (database != null){
                database = Room.databaseBuilder(context,LocalDB::class.java, "stations.db").build()
            }
            return database!!
        }
    }

    abstract fun stationDao():StationDao

}