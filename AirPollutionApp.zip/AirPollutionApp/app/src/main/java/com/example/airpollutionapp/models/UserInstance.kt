package com.example.airpollutionapp.models

object UserInstance {

    val id:String=""
    val email:String=""
    val phone:String=""
    val region:String=""
    val password:String=""
   // val stations= mutableListOf<Station>()
}