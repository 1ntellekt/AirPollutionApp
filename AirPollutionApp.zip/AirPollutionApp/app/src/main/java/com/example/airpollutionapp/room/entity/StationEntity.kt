package com.example.airpollutionapp.room.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Station")
data class StationEntity(
    @PrimaryKey(autoGenerate = true)
    var id:Int? = null,
    @ColumnInfo(name = "name")
    var name: String ="",
    @ColumnInfo(name = "longitude")
    var longitude:Double=0.0,
    @ColumnInfo(name = "latitude")
    var latitude:Double=0.0,
    @ColumnInfo(name = "address")
    var address: String ="",
    @ColumnInfo(name = "city")
    var city: String ="",

    @ColumnInfo(name = "co")
    var co: Double = 0.0,
    @ColumnInfo(name = "no")
    var no: Double = 0.0,
    @ColumnInfo(name = "no2")
    var no2: Double = 0.0,
    @ColumnInfo(name = "so2")
    var so2: Double = 0.0,
    @ColumnInfo(name = "nh3")
    var nh3: Double = 0.0,
    @ColumnInfo(name = "pm10")
    var pm10: Double = 0.0,
    @ColumnInfo(name = "pm2.5")
    var pm2_5: Double = 0.0
)
